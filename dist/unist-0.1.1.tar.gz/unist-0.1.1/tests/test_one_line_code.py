"""Tests for one_line_code helpers (InterpolAI/SUICA integration tests are optional)."""

import numpy as np
import pytest
from anndata import AnnData


def _make_slice(n=40, z=None, genes=20, label_prefix="A"):
    rng = np.random.default_rng(0)
    xy = rng.random((n, 2)) * 10
    spatial = xy if z is None else np.column_stack([xy, np.full(n, z)])
    adata = AnnData(X=rng.random((n, genes)).astype(np.float32))
    adata.obsm["spatial"] = spatial
    adata.obs["cell_type"] = [f"{label_prefix}{i % 3}" for i in range(n)]
    adata.var_names = [f"g{i}" for i in range(genes)]
    return adata


def test_occupancy_roundtrip():
    from unist.one_line_code.occupancy import (
        auto_grid_size,
        rasterize_occupancy,
        sample_coords_from_occupancy,
        shared_bbox,
        to_3channel,
    )

    a = _make_slice(n=30, z=0.0)
    b = _make_slice(n=30, z=2.0)
    b.var_names = a.var_names
    xy_a = a.obsm["spatial"][:, :2]
    xy_b = b.obsm["spatial"][:, :2]
    bbox = shared_bbox(xy_a, xy_b)
    hw = auto_grid_size(xy_a, xy_b, bbox, max_side=128)
    img = to_3channel(rasterize_occupancy(xy_a, bbox, hw))
    assert img.shape[-1] == 3
    coords = sample_coords_from_occupancy(img, bbox, z=1.0, threshold=1.0)
    assert coords.shape[1] == 3
    assert coords.shape[0] > 0


def test_nn_annotate():
    from unist.one_line_code.nn_annotate import transfer_1nn
    from unist.one_line_code.suica_backend import stack_flanking_3d

    a = _make_slice(n=20, z=0.0)
    b = _make_slice(n=20, z=2.0)
    b.var_names = a.var_names
    xyz_a = np.column_stack([a.obsm["spatial"][:, :2], np.zeros(20)])
    xyz_b = np.column_stack([b.obsm["spatial"][:, :2], np.full(20, 2.0)])
    ref = stack_flanking_3d(a, b, xyz_a, xyz_b)
    query = np.column_stack(
        [a.obsm["spatial"][:10, :2], np.full(10, 1.0)]
    )
    out = transfer_1nn(
        np.asarray(ref.obsm["spatial"]),
        query,
        ref,
        label_key="cell_type",
    )
    assert "predicted_celltype" in out.obs
    assert out.n_obs == 10


def test_hybrid_annotate():
    from unist.one_line_code.nn_annotate import annotate_with_hybrid, transfer_hybrid_nn

    rng = np.random.default_rng(1)
    n, m, d = 30, 8, 4
    ref_coords = rng.normal(size=(n, 3))
    query_coords = rng.normal(size=(m, 3))
    ref_emb = rng.normal(size=(n, d))
    # make query embeddings close to first m refs
    query_emb = ref_emb[:m] + rng.normal(scale=0.01, size=(m, d))
    labels = np.array([f"T{i % 3}" for i in range(n)])
    pred, idx, alpha = transfer_hybrid_nn(
        ref_coords, query_coords, ref_emb, query_emb, labels, alpha=0.05
    )
    assert len(pred) == m
    assert 0.0 <= alpha <= 1.0

    ref = _make_slice(n=n, z=0.0, genes=5)
    mid = AnnData(X=np.zeros((m, 5), dtype=np.float32))
    mid.obsm["fitted_embd"] = query_emb
    mid.obsm["spatial_normalized"] = query_coords
    mid.obsm["spatial"] = query_coords.copy()
    emb = AnnData(X=np.zeros((n, 5), dtype=np.float32))
    emb.obsm["embeddings"] = ref_emb
    emb.obsm["spatial"] = ref_coords
    annotate_with_hybrid(mid, ref, emb, label_key="cell_type", alpha="auto")
    assert "predicted_celltype" in mid.obs
    assert mid.uns["unist"]["annotation"] == "hybrid_nn"


def test_import_one_line_code():
    from unist.one_line_code import predict_middle_slice
    from unist import predict_middle_slice as top

    assert predict_middle_slice is not None
    assert top is not None
