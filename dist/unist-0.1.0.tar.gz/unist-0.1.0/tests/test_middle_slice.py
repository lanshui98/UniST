"""Tests for middle-slice prediction API."""

import numpy as np
import pandas as pd
import pytest
from anndata import AnnData


def _make_slice(n=40, z=None, genes=20, label_prefix="A"):
    rng = np.random.default_rng(0)
    xy = rng.random((n, 2)) * 10
    if z is None:
        spatial = xy
    else:
        spatial = np.column_stack([xy, np.full(n, z)])
    X = rng.random((n, genes)).astype(np.float32)
    adata = AnnData(X=X)
    adata.obsm["spatial"] = spatial
    adata.obs["cell_type"] = [f"{label_prefix}{i % 3}" for i in range(n)]
    adata.var_names = [f"g{i}" for i in range(genes)]
    return adata


def test_fast_mode_labels():
    from unist.middle_slice import predict_middle_slice

    a = _make_slice(n=30, z=0.0, label_prefix="A")
    b = _make_slice(n=30, z=2.0, label_prefix="B")
    # share gene names
    b.var_names = a.var_names
    mid = predict_middle_slice(a, b, mode="fast", label_key="cell_type")
    assert mid.n_obs == 60  # union of XY
    assert "predicted_celltype" in mid.obs
    assert mid.obsm["spatial"].shape == (60, 3)
    assert np.allclose(mid.obsm["spatial"][:, 2], 1.0)


def test_fast_mode_2d_defaults():
    from unist.middle_slice import predict_middle_slice

    a = _make_slice(n=20, z=None)
    b = _make_slice(n=20, z=None)
    b.var_names = a.var_names
    mid = predict_middle_slice(a, b, mode="fast", label_key="cell_type", query="a")
    assert mid.n_obs == 20
    assert np.allclose(mid.obsm["spatial"][:, 2], 0.5)


@pytest.mark.slow
def test_inr_mode_smoke():
    from unist.middle_slice import predict_middle_slice

    a = _make_slice(n=40, z=0.0, genes=15)
    b = _make_slice(n=40, z=1.0, genes=15)
    b.var_names = a.var_names
    mid = predict_middle_slice(
        a,
        b,
        mode="inr",
        label_key="cell_type",
        n_pcs=5,
        epochs=5,
        batch_size=32,
        query="a",
    )
    assert mid.X.shape == (40, 15)
    assert "predicted_celltype" in mid.obs
    assert mid.uns["unist"]["mode"] == "inr"
