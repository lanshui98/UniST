<h1>
  UniST
  <img src="whole.gif" width="160" align="right">
</h1>

### [🌐 Tutorial Website](https://unist-tutorial.readthedocs.io/en/latest/)

A Unified Computational Framework for 3D Spatial Transcriptomics Reconstruction.

<p align="center">
  <img src="fig.png" width="1000">
</p>

## Installation

**From PyPI (recommended):**

```bash
pip install unist
```

**Full extras** (InterpolAI / PyVista / Lightning pipelines):

```bash
pip install "unist[full]"
```

**From GitHub:**

```bash
pip install git+https://github.com/lanshui98/UniST.git
```

**Using requirements.txt:**

```bash
pip install -r requirements.txt
```

#### Build CUDA extensions (only for upsampling)

```bash
python setup_cuda_extensions.py
```

## Quick Start — middle slice (one line)

Given two flanking ST slices (`AnnData` with `obsm["spatial"]`):

```python
from unist import predict_middle_slice

# Fast: cell-type annotation via 1-nearest neighbor
middle = predict_middle_slice(slice_a, slice_b, mode="fast", label_key="cell_type")

# INR: gene expression on the middle plane
middle = predict_middle_slice(slice_a, slice_b, mode="inr")
```

- **fast** — places query spots on the mid-z plane and transfers `label_key` from the nearest flanking cell (optional `transfer_expression=True`).
- **inr** — trains a lightweight Fourier-feature INR on both slices and predicts expression at mid-z (optional `label_key` adds 1-NN cell types).

## Upsampling
[Tutorial Page](https://unist-tutorial.readthedocs.io/en/latest/upsampling.html)

```
python -m upsampling.test_upsampling \
    --dataset pugan \
    --input_dir /path/to/input/pointclouds \
    --ckpt /path/to/pretrain/ckpt-best.pth \
    --r 2 \
    --save_dir /path/to/output \
    --flexible \
    --no_gt
```

**Arguments:**
- `--dataset`: Dataset type
- `--input_dir`: Directory containing input `.xyz` point cloud files
- `--ckpt`: Path to model checkpoint file (e.g., `pretrain/ckpt-best.pth`)
- `--r`: Upsampling rate
- `--save_dir`: Directory to save upsampled point clouds
- `--flexible`: Enable flexible upsampling rate (recommended)
- `--no_gt`: Skip evaluation (use when you don't have ground truth)

**Pre-trained weights**

Download the weights from google drive [link](https://drive.google.com/file/d/1af_de8YnG5eOAJaSDy1C5CmZRqaCCYb-/view?usp=sharing) and put under ./external/RepKPU_ops/pretrain/

### Interpolation

[Tutorial Page](https://unist-tutorial.readthedocs.io/en/latest/interpolation.html)

```
python -m interpolation.main \
    --mode auto \
    --tile_size 1024 1024 \
    --pth /path/to/image/folder
```

**Modes:**
- `auto`: Automatically detect and interpolate missing slices
- `no_skip`: Interpolate without skipping slices (requires `--skip` argument)
- `skip`: Interpolate with specified skip values (requires `--skip` argument)

**Pre-trained weights**

Download the weights from google drive [link](https://drive.google.com/drive/folders/1zw6kgpnxat_CEFoDWaVIHndxuKqk5vmD?usp=sharing) and put under ./external/InterpolAI/interpolation/

### Gene imputation

[Tutorial Page](https://unist-tutorial.readthedocs.io/en/latest/gene_imputation.html) - [Model Details](https://github.com/lanshui98/SUICA_pro)

## Citation
If you find our work is useful, please cite:

Shui, L., Liu, Y., Julio, I.C., Clemenceau, J.R., Hoi, X.P., Dai, Y., Lu, W., Min, J., Khan, K., Roemer, B. and Jiang, M., 2026. UniST: A Unified Computational Framework for 3D Spatial Transcriptomics Reconstruction. bioRxiv, pp.2026-03.
